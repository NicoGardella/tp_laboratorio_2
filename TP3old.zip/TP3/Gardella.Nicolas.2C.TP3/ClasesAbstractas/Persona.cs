﻿using Excepciones;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ClasesAbstractas
{
    public abstract class Persona
    {
        public enum ENacionalidad
        {
            Argentino, Extranjero
        }
        #region atributos
        private string nombre;
        private string apellido;
        private ENacionalidad nacionalidad;
        private int dni;
        #endregion
        #region propiedades
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                try
                {
                    string nombreV = ValidarNombreApellido(value);
                    if (nombreV != null)
                    {
                        this.nombre = nombreV;
                    }
                }
                catch (Exception)
                {

                    // throw;
                }
            }
        }
        public string Apellido
        {
            get
            {
                return this.apellido;
            }
            set
            {
                string apellidoV = ValidarNombreApellido(value);
                if (apellidoV != null)
                {
                    this.apellido = apellidoV;
                }
            }
        }
        public int DNI
        {
            get
            {
                return this.dni;
            }
            set
            {
                try
                {
                    this.dni = ValidarDni(this.nacionalidad, value);
                }
                catch (Exception)
                {

                    // throw;
                }
            }
        }
        public ENacionalidad Nacionalidad
        {
            get
            {
                return this.nacionalidad;
            }
            set
            {
                this.nacionalidad = value;

            }
        }
        public string StringToDNI
        {
            set
            {
                try
                {
                    this.dni = ValidarDni(this.nacionalidad, value);
                }
                catch (Exception)
                {

                    // throw;
                }
            }
        }
        #endregion
        #region metodos
        public Persona()
        {
        }
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.DNI = dni;
        }
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.StringToDNI = dni;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Nombre y Apellido: ");
            sb.AppendLine(this.Nombre + " " + this.Apellido);
            sb.Append("Nacionalidad: ");
            sb.AppendLine(this.Nacionalidad.ToString());
            sb.Append("Dni: ");
            sb.AppendLine(this.DNI.ToString());
            return sb.ToString();
        }
        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            if (dato > 99999999)
            {
                throw new DniInvalidoException();
            }
            else if (nacionalidad == ENacionalidad.Argentino)
            {
                if (dato < 1 || dato > 89999999)
                {
                    throw new NacionalidadInvalidaException();
                }
            }
            else if ((nacionalidad == ENacionalidad.Extranjero))
            {
                if (dato < 90000000)
                {
                    throw new NacionalidadInvalidaException();
                }
            }
            return dato;
        }
        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int intDni;
            if (int.TryParse(dato, out intDni))
            {
                return ValidarDni(nacionalidad, intDni);
            }
            else
            {
                throw new DniInvalidoException();
            }
        }
        private string ValidarNombreApellido(string dato)
        {
            if (!Regex.IsMatch(dato, @"^[a-zA-Z]+$"))
            {
                return null;
            }
            return dato;
        }
        #endregion
    }
}
